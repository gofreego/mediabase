package constants

const (
	DefaultPageSize = 10
	MaxPageSize     = 100
)
