package constants

const (
	HTTP_SERVER = "HTTP_SERVER"
	GRPC_SERVER = "GRPC_SERVER"
)
